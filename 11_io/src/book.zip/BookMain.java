package book;

public class BookMain {
	
	public static void main(String[] args) {
		BookService bookService = new BookService();
		
		bookService.menu();
	}
}
