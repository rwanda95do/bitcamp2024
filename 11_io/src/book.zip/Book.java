package book;

import java.util.ArrayList;


public interface Book {
	public void execute(ArrayList<BookDTO> list);
}
